import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
df = pd.read_csv('data/survey_responses.csv')

print(f"✅ 共收集到 {len(df)} 份有效问卷\n")

# ==================== 1. 基本统计 ====================
print("=== 年龄分布 ===")
print(df['age'].value_counts())

print("\n=== 家庭月收入分布 ===")
print(df['income'].value_counts())

print("\n=== 生活幸福感平均分 ===")
print(f"平均分：{df['happiness'].astype(float).mean():.2f} 分")

# ==================== 2. 生成可视化图表 ====================
sns.set_style("whitegrid")

# 创建图表文件夹
os.makedirs('charts', exist_ok=True)

# 图1：年龄分布
plt.figure(figsize=(8, 5))
df['age'].value_counts().plot(kind='bar', color='#ff6b9d')
plt.title('中年妇女年龄分布')
plt.xlabel('年龄段')
plt.ylabel('人数')
plt.xticks(rotation=0)
plt.savefig('charts/01_年龄分布.png', dpi=200, bbox_inches='tight')
plt.close()

# 图2：收入分布
plt.figure(figsize=(8, 5))
df['income'].value_counts().plot(kind='bar', color='#ff9a9e')
plt.title('家庭月收入分布')
plt.xlabel('月收入（元）')
plt.ylabel('人数')
plt.xticks(rotation=15)
plt.savefig('charts/02_收入分布.png', dpi=200, bbox_inches='tight')
plt.close()

# 图3：幸福感分布
plt.figure(figsize=(8, 5))
df['happiness'].astype(float).hist(bins=8, color='#c4458f', alpha=0.8)
plt.title('生活幸福感评分分布')
plt.xlabel('幸福感评分 (1-10分)')
plt.ylabel('人数')
plt.savefig('charts/03_幸福感分布.png', dpi=200, bbox_inches='tight')
plt.close()

# 图4：主要消费品类（多选拆分）
categories = df['category'].str.split(' \\| ', expand=True).stack().value_counts()
plt.figure(figsize=(10, 6))
categories.plot(kind='barh', color='#ff6b9d')
plt.title('主要消费品类统计')
plt.xlabel('选择次数')
plt.savefig('charts/04_消费品类.png', dpi=200, bbox_inches='tight')
plt.close()

print("\n🎉 图表生成完成！")
print("请查看项目文件夹中的 'charts' 文件夹，里面有4张分析图表。")