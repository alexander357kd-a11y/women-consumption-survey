from flask import Flask, render_template, request, jsonify
import pandas as pd
from datetime import datetime
import os

app = Flask(__name__)

# 创建数据文件夹
os.makedirs('data', exist_ok=True)
print("✅ 数据文件夹已准备好")

@app.route('/')
def index():
    return render_template('survey.html')

@app.route('/submit', methods=['POST'])
def submit():
    try:
        print("📥 收到提交请求！")
        
        form_data = request.form.to_dict()
        print("表单原始数据:", form_data)
        
        # 处理多选题
        for key in list(request.form.keys()):
            values = request.form.getlist(key)
            if len(values) > 1:
                form_data[key] = ' | '.join(values)
        
        form_data['提交时间'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        df = pd.DataFrame([form_data])
        file_path = 'data/survey_responses.csv'
        
        if os.path.exists(file_path):
            df.to_csv(file_path, mode='a', header=False, index=False, encoding='utf-8-sig')
            print("✅ 数据追加到CSV文件")
        else:
            df.to_csv(file_path, index=False, encoding='utf-8-sig')
            print("✅ 新建CSV文件并保存数据")
        
        return jsonify({"status": "success", "message": "提交成功！"})
        
    except Exception as e:
        print("❌ 错误:", str(e))
        return jsonify({"status": "error", "message": str(e)})

if __name__ == '__main__':
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)